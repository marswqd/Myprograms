# !/bin
#
ps=trantola_inversion.ps
gmtset PLOT_DEGREE_FORMAT ddd:mm:ssF
gmtset HEADER_FONT_SIZE 20p
gmtset LABEL_FONT_SIZE 15P
makecpt -Crainbow -T2/5/0.1 -I -Z > velocity.cpt 
#xyz2grd INVERSION_VELOCITY_STRUCTURE.TXT -GINVERSION_VELOCITY_STRUCTURE.grd \
#       -H2 -I300m/300m -R57.5/162.5/-7.5/77.5 -:
surface INVERSION_VELOCITY_STRUCTURE.TXT -GINVERSION_VELOCITY_STRUCTURE.grd \
       -H2 -I10m/10m -R70/140/10/55 -:

grdimage INVERSION_VELOCITY_STRUCTURE.grd -Cvelocity.cpt \
        -R70/140/10/55 -JL105/35/25/45/6.5i \
         -B20f10/10f5:."Inversion Velocity": -K -X2.5i -Y2i > $ps
     
pscoast -J -R -B -K -O -W -N1 -A5000 >> $ps

psscale  -B0.2 -Y-0.75i -D3.25i/.1i/4i/.2ih -Cvelocity.cpt  \
         -O -I -S >> $ps

