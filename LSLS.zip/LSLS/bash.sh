#!/bin/sh
gfortran lslsinversion.f90 -o lsls
./lsls
gfortran lsls_zhu.f90 -o lslszhu
./lslszhu
gfortran grd0.f90 -o grd0
./grd0
